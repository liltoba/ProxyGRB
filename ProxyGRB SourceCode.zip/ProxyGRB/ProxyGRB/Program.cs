﻿using Colorful;
using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using Console = Colorful.Console;

namespace ProxyGRB
{

    //Coded By LilToba :)

    //    Telegram Channel : https://t.me/ghoulblack

    //    LilToba Telegram : https://t.me/liltoba



    class Program
    {
        private static string SavePath => string.Concat(Directory.GetCurrentDirectory(), "\\Proxy");

        static void Main(string[] args)
        {

            int DA = 244;
            int V = 212;
            int ID = 255;
            for (int i = 0; i < 1; i++)
            {
                Console.WriteAscii("ProxyGRB", Color.FromArgb(DA, V, ID));

                DA -= 18;
                V -= 36;
            }
            Console.WriteLine("ProxyGRB Coded By LilToba :) \n", Color.Red);
            Console.WriteLine("1) HTTP", Color.LightGreen);
            Console.WriteLine("2) Socks4", Color.MistyRose);
            Console.WriteLine("3) Socks5" , Color.Goldenrod);
            Console.WriteLine("4) About", Color.Aquamarine);

            var input =  Console.ReadLine();

            if(input == "1")
            {
                HttpWebResponse response = (HttpWebResponse)((HttpWebRequest)WebRequest.Create("https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=10000&country=all&anonymity=all&ssl=yes")).GetResponse();
                string end = (new StreamReader(response.GetResponseStream())).ReadToEnd();
                MatchCollection matchCollections = (new Regex("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}")).Matches(end);
                Console.WriteLine(end);
                File.WriteAllText(SavePath + "\\Http.txt", end);
                Console.WriteLine(Environment.NewLine + "=> Proxy Http Successfully Grabbed & Save.");
             Console.ReadLine();
            }
            if(input == "2")
            {
                HttpWebResponse response1 = (HttpWebResponse)((HttpWebRequest)WebRequest.Create("https://api.proxyscrape.com?request=getproxies&proxytype=socks4&timeout=10000&country=all")).GetResponse();
                string end1 = (new StreamReader(response1.GetResponseStream())).ReadToEnd();
                MatchCollection matchCollections1 = (new Regex("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}")).Matches(end1);
                Console.WriteLine(end1);
                File.WriteAllText(SavePath + "\\Socks4.txt", end1);
                Console.WriteLine(Environment.NewLine + "=> Proxy Socks4 Successfully Grabbed & Save.");
                Console.ReadLine();
            }
            if (input == "3")
            {
   
                HttpWebResponse response2 = (HttpWebResponse)((HttpWebRequest)WebRequest.Create("https://api.proxyscrape.com?request=getproxies&proxytype=socks5&timeout=10000&country=all")).GetResponse();
                string end2 = (new StreamReader(response2.GetResponseStream())).ReadToEnd();
                MatchCollection matchCollections2 = (new Regex("[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}:[0-9]{1,5}")).Matches(end2);
                Console.WriteLine(end2);
                File.WriteAllText(SavePath + "\\Socks5.txt", end2);
                Console.WriteLine(Environment.NewLine + "=> Proxy Socks5 Successfully Grabbed & Save.");
                Console.ReadLine();
            }

            if(input == "4")
            {

                string dream = "This Program Coded By {0} Telegram Channel {1} Telegram ID {2} This Program Is {3} And Coded With {4} You Can Use In {5}...";
                Formatter[] fruits = new Formatter[]
                {
    new Formatter("LilToba", Color.LightGoldenrodYellow),
    new Formatter("https://t.me/ghoulblack", Color.Pink),
    new Formatter("https://t.me/liltoba", Color.PeachPuff),
    new Formatter("OpenSource", Color.Yellow),
    new Formatter("C#", Color.Red),
    new Formatter("Linux And Windows", Color.Orange),
    new Formatter("apples", Color.LawnGreen),
    new Formatter("peaches", Color.MistyRose),
    new Formatter("plums", Color.Indigo),
    new Formatter("melons", Color.LightGreen),
                };

                Console.WriteLineFormatted(dream, Color.Gray, fruits);
                Console.ReadLine();
            }

        }
    }
}
